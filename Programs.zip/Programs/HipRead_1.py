# Program for reading data from Hipparcos catalogue and Table-2 of Deb & Chakraborty 2014
f1=open("D:/Programs/data_deb.txt",'r+')
data_deb=f1.readlines()
f2=open("D:/Programs/hip_main.dat", "r+")
data_hip=f2.readlines()
hiplist=[]
RA_DEC=[]
d_parsec=[]
log10T=[]
log10T_Error=[]
Mv=[]
for data in data_deb:
    data_list=data.split("\t") # Data file separator is <Tab> ('\t' in Python) in 'data_deb.txt'
    if data_list[7]=="Unchanged" or data_list[7]=="Unchanged\n":  # There are some lines with <Enter> ('\n' in Python) after 'Unchanged'
        hiplist.append(int(data_list[0])) # records Hippracos identifier 
        for data2 in data_hip:
            data2_list=data2.split("|") # Data file separator is '|' in 'hip_main.dat'
            if int(data_list[0])==int(data2_list[1]):
                # float conversion is required because element types are str in all cases
                # but there may be some data with NO entry (i.e. blank spaces)
                # these will lead to error while convertig to float values
                # therefore try-except statement is used
                try:
                    RA_DEC.append([float(data2_list[8]),float(data2_list[9])]) # recording co-ordinates
                except:
                    RA_DEC.append("No_data") 
                try:
                    d_parsec.append((10**3)/float(data2_list[11])) # recording distance in parsec
                except:
                    d_parsec.append("No_data") 
                try:
                    log10T.append((14.551-float(data2_list[37]))/3.684) # recording (B-V) index
                except:
                    log10T.append("No_data") 
                try:
                    log10T_Error.append(float(data2_list[38])/3.684) # recording (B-V) Error
                except:
                    log10T_Error.append("No_data") 
                try:
                    Mv.append(float(data_list[3])) # recording 4th column of 'data_deb.txt' (index=0 for 1st column)
                except:
                    Mv.append("No_data")               
for i in range(len(hiplist)):
    print(hiplist[i],'\t',RA_DEC[i],'\t',d_parsec[i],'\t',log10T[i],'\t',log10T_Error[i],'\t',Mv[i])
print(len(hiplist))


