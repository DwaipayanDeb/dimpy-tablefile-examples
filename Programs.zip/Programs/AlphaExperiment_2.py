# Program for determination of temperature co-efficient of resistance 
from tablefile import *
import matplotlib.pyplot as plt
from math import *
import numpy as np

f1=file("D:/Programs/AlphaExpData.txt",',')
cols=f1.read("c/l") # Reading data column-wise
N_col=4 # Number of columns in the data
N=50 # Number of observations at a time
j=1
Result=[] # A temporary list to hold T_av, T_err, V_av, V_err, I_av and I_err at a given time
temperature=[] # List for holding final average temperature data
resistance=[] # List for holding final resistance data
temperature_err=[] # List for holding temperature standard error data
resistance_err=[] # List for holding resistance uncertainty data
for i in range(0,len(cols[j]),N):
    for j in range(1,N_col):
        Result.append(av(cols[j][i:i+N])) # Calculation of T_av (for j=1), V_av (for j=2) or I_av (for j=3)
        Result.append(sds(cols[j][i:i+N])/sqrt(N)) # Standard errors T_err, V_err or I_err
    V_av=av(cols[2][i:i+N]) # Average of voltage data
    V_err=sds(cols[2][i:i+N])/sqrt(N) # Standard error of voltage data
    I_av=av(cols[3][i:i+N]) # Average of current data
    I_err=sds(cols[3][i:i+N])/sqrt(N) # Standard error of current data
    R=V_av/I_av # Calculation of resistance
    Result.append(R) 
    R_delta=R*((V_err/V_av)+(I_err/I_av))  # Uncertainty in R measurement
    Result.append(R_delta)
    temperature.append(Result[0])
    temperature_err.append(Result[1]) # Standard Error in T measurement
    resistance.append(Result[6])
    resistance_err.append(Result[7]) # Uncertainty in R measurement R_delta
    print(Result)
    Result=[]
#print(temperature_err,resistance_err)
m,b=np.polyfit(temperature,resistance,1) # Fitting a line of slope m and intercept b to the data
print("Alpha_fitted=",m/b)
plt.xlim(0,100) # Limits of x_axis range for plot
plt.title("Determination of temperature coefficient of resistance")
plt.xlabel("Temperature (deg. C)")
plt.ylabel("Resistance (Ohm)")
x=np.linspace(0,100) # defining range of x values
plt.plot(x,m*x+b) # plotting the fitted line
# Plotting with error-bars
plt.errorbar(temperature,resistance,xerr=temperature_err,yerr=resistance_err, color="red",fmt='o',markersize=5)
plt.show()