# Test for Symplectic Condition (Sol to 1st part of Q8 in Goldstein p431])
from sympy import *
from dimpy import *

n=2 # Number of Particles
q1,q2,p1,p2=symbols('q1,q2,p1,p2') # Symbolic variables are declared
Q1=q1
Q2=p2
P1=p1-2*p2
P2=-2*q1-q2
X=[q1,q2,p1,p2]
Y=[Q1,Q2,P1,P2]
M=dim(2*n,2*n) # Simplest alternative to this would be: M=Array([[0,0],[0,0]]) but it would lead to error if derivatives of the Jacobian matrix are not constants
J=dim(2*n,2*n)
for i in range(2*n):
    for j in range(2*n):
        M[i][j]=diff(Y[i],X[j]) # Jacobian matrix M

        if i<n and i==(j-n):   # Antisymmetric matrix J
            J[i][j]=1
        elif i>=n and j==(i-n):
            J[i][j]=-1       
M=Matrix(M) # Array M is converted into a sympy matrix
J=Matrix(J) # Array J is converted into a sympy matrix
if M.T*J*M==J: # M.T is the tanspose of M
    print("The symplectic condition is satisfied")
else:
    print("The test was not successful")
