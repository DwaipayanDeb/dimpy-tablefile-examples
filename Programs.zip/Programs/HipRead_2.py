# Program for reading data from Hipparcos catalogue and Table-2 of Deb & Chakraborty 2014
from tablefile import *
f1=file("D:/Programs/data_deb.txt",'\t')
lines_deb=[]
f1.read(lines_deb) # reads 'data_deb.txt' in default line/column format 
f2=file("D:/Programs/hip_main.dat", "|")
cols_hip=[]
f2.read(cols_hip,"c/l") # reads 'hip_main.dat' in column/line format
hiplist=[]
RA_DEC=[]
pi_H=[]
B_V=[]
B_V_Error=[]
Mv=[]
for line in lines_deb:
    index=0
    if (line[7]=="Unchanged\n" or line[7]=="Unchanged"): # There are some lines with <Enter> ('\n' in Python) after 'Unchanged'
        hiplist.append(int(line[0])) # records Hippracos identifier 
        Mv.append(line[3])
        for column in cols_hip[1]: 
            if line[0]==column: 
                RA_DEC.append([cols_hip[8][index],cols_hip[9][index]]) # recording co-ordinates
                pi_H.append(cols_hip[11][index]) # recording parallax angle
                B_V.append(cols_hip[37][index]) # recording (B-V) 
                B_V_Error.append(cols_hip[38][index]) # recording error in(B-V)
            index+=1
d_parsec=convert(pi_H,'10**3/x') # converting parallax to distance in parsec
log10T=convert(B_V,'(14.551-x)/3.684') # converting (B-V) to log scale color temperature T
log10T_Error=convert(B_V_Error,'x/3.684') # converting (B-V) errors to error in logT scale 
for i in range(len(hiplist)):
    print(hiplist[i],'\t',RA_DEC[i],'\t',d_parsec[i],'\t',log10T[i],'\t',log10T_Error[i],'\t',Mv[i])
print("HIP ",len(hiplist))


'''f1=open("D:/My Folder/My Works/Hip/DebChakraTable.txt",'r+')
data_deb=f1.readlines()
f2=open("D:/My Folder/My Works/Hip/Paper-1/hip-main(LIST-1).dat", "r+")
data_hip=f2.readlines()
hiplist=[]
RA_DEC=[]
d_parsec=[]
log10T=[]
log10T_Error=[]
Mv=[]
for data in data_deb:
    data_list=data.split("\t") # Data file separator is <Tab> ('\t' in Python) in 'data_deb.txt'
    if data_list[7]=="Unchanged" or data_list[7]=="Unchanged\n":  # There are some lines with <Enter> ('\n' in Python) after 'Unchanged'
        hiplist.append(int(data_list[0])) # records Hippracos identifier 
        for data2 in data_hip:
            data2_list=data2.split("|") # Data file separator is '|' in 'hip_main.dat'
            if int(data_list[0])==int(data2_list[1]):
                # float conversion is required because element types are str in all cases
                # but there may be some data with NO entry (i.e. blank spaces)
                # these will lead to error while convertig to float values
                # therefore try-except statement is used
                try:
                    RA_DEC.append([float(data2_list[8]),float(data2_list[9])]) # recording co-ordinates
                except:
                    RA_DEC.append("No_data") 
                try:
                    d_parsec.append((10**3)/float(data2_list[11])) # recording distance in parsec
                except:
                    d_parsec.append("No_data") 
                try:
                    log10T.append((14.551-float(data2_list[37]))/3.684) # recording (B-V) index
                except:
                    log10T.append("No_data") 
                try:
                    log10T_Error.append(float(data2_list[38])/3.684) # recording (B-V) Error
                except:
                    log10T_Error.append("No_data") 
                try:
                    Mv.append(float(data_list[3])) # recording 4th column of 'data_deb.txt' (index=0 for 1st column)
                except:
                    Mv.append("No_data")               
for i in range(len(hiplist)):
    print(hiplist[i],'\t',RA_DEC[i],'\t',d_parsec[i],'\t',log10T[i],'\t',log10T_Error[i],'\t',Mv[i])
print(len(hiplist))'''


