# Program for determining Hessian matrix of a function
from sympy import *
from math import pi
from dimpy import *
x1,x2,x3,x4,x5=symbols('x1,x2,x3,x4,x5') # Defines the symbolic variables
x=[x1,x2,x3,x4,x5]
f=x1**2+x1*x2+cos(x1*x2)+x3+x4*x5**0.5 # Defines the function
n=5 # Number of rows or columns
H=dim(n,n) # Closest alternative to this would be: H=Array([[0,0],[0,0]]) or Array(range(4),(2,2)) but it would lead to error if derivatives of the Hessian matrix are not constants(i.e. numbers)
for i in range(n):
    for j in range(n):
        H[i][j]=diff(diff(f,x[j]),x[i])
print(H)
H=Matrix(H).subs([(x1,1),(x2,pi),(x3,1),(x4,7),(x5,3)]) # Converts H into a Sympy Matrix then evaluates H at point (x1,x2,x3,x4,x5)=(1,3.1416,1,0,3) 
print(det(H)) # Determinant of H
print(H.eigenvals()) # Eigen values of H
print(H.eigenvects()) # Eigen vectors of H

